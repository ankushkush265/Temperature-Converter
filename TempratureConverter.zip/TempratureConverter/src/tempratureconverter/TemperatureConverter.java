package tempratureconverter;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.*;

public class TemperatureConverter {
    private JFrame frame;
    private JLabel inputLabel,outputLabel;
    private JTextField input;
    private JTextField output;
    private JComboBox<String> fromUnit;
    private JComboBox<String> toUnit;
    private JButton covertButton;
    protected void initComponents(){
        frame= new JFrame("TemperatureConverter");
        frame.setSize(500,200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        inputLabel=new JLabel("Input: ");
        input=new JTextField(10);
        outputLabel=new JLabel("Output: ");
        output=new JTextField(10);
        output.setEnabled(false);
        fromUnit=new JComboBox<String>(new String[]{"Celsius","Fahrenheit","Kelvin"});
        toUnit=new JComboBox<String>(new String[]{"Celsius","Fahrenheit","Kelvin"});
        covertButton=new JButton("Convert");

        inputLabel.setBounds(20,20,100,20);
        input.setBounds(150,20,140,20);
        fromUnit.setBounds(300,20,100,20);
        outputLabel.setBounds(20,50,100,20);
        output.setBounds(150,50,140,20);
        toUnit.setBounds(300,50,100,20);
        covertButton.setBounds(150,80,100,20);

        covertButton.addActionListener(new ConvertButtonListener());



        frame.add(inputLabel);
        frame.add(input);
        frame.add(fromUnit);
        frame.add(outputLabel);
        frame.add(output);
        frame.add(toUnit);
        frame.add(covertButton);

        frame.setVisible(true);

    }
    public TemperatureConverter(){
        initComponents();

    }
    public static void main(String args[]){
        new TemperatureConverter();
    }
    private class ConvertButtonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String fromUnitType = fromUnit.getSelectedItem().toString();
            String toUnitType = toUnit.getSelectedItem().toString();
            double inputValue = Double.parseDouble(input.getText());
            double outputValue = 0.0;
            if (fromUnitType.equals("Celsius")) {
                if (toUnitType.equals("Celsius")) {
                    outputValue = TemperatureConverter.celsiusToCelsius(inputValue);
                } else if (toUnitType.equals("Fahrenheit")) {
                    outputValue = TemperatureConverter.celsiusToFahrenheit(inputValue);
                } else if (toUnitType.equals("Kelvin")) {
                    outputValue = TemperatureConverter.celsiusToKelvin(inputValue);
                }

            } else if (fromUnitType.equals("Fahrenheit")) {
                if (toUnitType.equals("Fahrenheit")) {
                    outputValue = TemperatureConverter.fahrenheitToFahrenheit(inputValue);
                } else if (toUnitType.equals("Celsius")) {
                    outputValue = TemperatureConverter.fahrenheitToCelsius(inputValue);
                } else if (toUnitType.equals("Kelvin")) {
                    outputValue = TemperatureConverter.fahrenheitToKelvin(inputValue);
                } else if (fromUnitType.equals("Kelvin")) {
                    if (toUnitType.equals("Kelvin")) {
                        outputValue = TemperatureConverter.kelvinToKelvin(inputValue);
                    } else if (toUnitType.equals("Fahrenheit")) {
                        outputValue = TemperatureConverter.kelvinToFahrenheit(inputValue);
                    } else if (toUnitType.equals("Celsius")) {
                        outputValue = TemperatureConverter.kelvinToCelsius(inputValue);
                    }


                }
            }
            output.setText("" + outputValue);
        }
    }

    public static double celsiusToCelsius(double inputValue) {
        double outputValue;
        outputValue = inputValue;
        return outputValue;
    }

    public static double celsiusToFahrenheit(double inputValue) {
        double outputValue;
        outputValue = (inputValue * 9.0 / 5.0) + 32.0;
        return outputValue;
    }

    public static double celsiusToKelvin(double inputValue) {
        double outputValue;
        outputValue = inputValue + 273.15;
        return outputValue;
    }

    public static double fahrenheitToFahrenheit(double inputValue) {
        double outputValue;
        outputValue = inputValue;
        return outputValue;
    }

    public static double fahrenheitToCelsius(double inputValue) {
        double outputValue;
        outputValue = (inputValue - 32) * 5.0 / 9.0;
        return outputValue;
    }
    public static double fahrenheitToKelvin(double inputValue){
        double outputValue;
        outputValue=(inputValue-32)*5.0/9.0+273.15;
        return outputValue;
    }
    public static double kelvinToKelvin(double inputValue){
        double outputValue;
        outputValue=inputValue;
        return outputValue;
    }
    public static double kelvinToFahrenheit(double inputValue){
        double outputValue;
        outputValue=(inputValue-273.15)*5.0/9.0+32;
        return outputValue;
    }
    public static double kelvinToCelsius(double inputValue){
        double outputValue;
        outputValue=inputValue-273.15;
        return outputValue;
    }
}
